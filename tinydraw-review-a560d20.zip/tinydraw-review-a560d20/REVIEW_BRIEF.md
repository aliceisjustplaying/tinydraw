# TinyDraw Vector V2 external review packet

Packet date: 2026-08-16

Source commit: `a560d20726d79139eff686358b00690fb9264a86`
(`test: freeze the combined cold benchmark`)

This packet is a complete tracked source snapshot plus the unedited raw device
logs used for the current cold-render baseline and the three bounded cold
experiments. Start with this file, then read the authorities in the order below.

## Requested review

Please assess the current Vector V2 architecture and recommend the next bounded
step toward shipping, with special attention to these linked problems:

1. Committed ink is still visibly more angular than the owner wants.
2. The curved-authority fix improved glass appearance but increased exact cold
   replay from roughly 664 ms to roughly 1.057 s on the tapered-only corpus.
3. The frozen general corpus now includes Sarah's evil hairlines and measures
   1.269 s maximum at 400%, versus a 500 ms requirement.
4. Settled anti-aliasing remains unimplemented. Four-sample SSAA measured about
   808 ms at 100% and is explicitly rejected.

Please answer:

- Is one bounded direct-quadratic/analytic curve raster experiment the right
  next step, and what exact representation or inner loop would you test?
- Can the stroke geometry become smoother while using fewer exact replay
  primitives than the current two line segments per curve unit?
- Is the 500 ms combined-corpus target still credible on this hardware without
  a broad checkpoint cache or reduced correctness?
- What settled-AA design can refine dirty regions after lift, remain cached on
  revisit, and avoid entering the live-ink or cold critical path?
- Are the benchmark, authority, memory, or timing conclusions wrong or missing
  a confounder?

The desired answer is concrete: predicted cost reduction, data structures,
exactness risks, byte budget, falsifying measurement, and stop/go threshold.
Do not recommend a rewrite unless the supplied evidence proves the current
architecture cannot meet the contract.

## First-read order

1. `source/PRODUCT_TENETS.md`
2. `source/SHIP_CONTRACT.md`
3. `source/PROJECT_STATE.md`
4. `source/V2_ROADMAP.md`
5. `source/benchmark-results/wave2-compositor/COLD_GENERAL_BASELINE_RECEIPT.md`
6. The three other `COLD_*_RECEIPT.md` experiment receipts in that directory
7. `source/benchmark-results/wave2-compositor/CURVED_AUTHORITY_GLASS_RECEIPT.md`
8. `source/benchmark-results/wave2-compositor/VISUAL_FIRST_INK_RECEIPT.md`
9. `source/HARDWARE_LIMITS.md`

## Current product facts

- Hardware: ESP32-S3 at 240 MHz, 8 MiB PSRAM, 368x448 RGB565 CO5300 panel.
- Requested 50 MHz panel clock is divider-limited to 40 MHz effective.
- Pan is owner-accepted tear-free at 50%, 100%, 200%, and 400%. PANSEQ p95 is
  about 33.94 ms at 100% and 400%.
- Visual-first ink reaches DMA in low single-digit milliseconds in the current
  instrumentation. Its remaining issue is geometry smoothness, graded yellow.
- Vector authority is blank baseline plus ordered operations. Detail tiles,
  overview, chrome, preview, and future settled AA are derived state.
- Exact painter order, Undo/export fidelity, and deterministic replay are
  requirements. Approximate raster equivalence is not accepted.
- The final allocation has 448 raw 64x64 slots. Holding the 1.5 MiB export
  reserve leaves roughly 306 KiB free, so broad viewport checkpoints are not
  currently funded.

## Current cold baseline

The frozen general corpus layers two deterministic workloads in one document:

- tapered adversarial: 128 operations, 4,096 samples;
- evil hairlines: 782 operations, 8,061 samples;
- total: 910 operations, 12,157 samples.

At 400%, origin `(0,0)`, from discarded detail tiles through final exact panel
publication and DMA completion:

| Statistic | Wall | Compute | Present | Pacing | Touch |
|---|---:|---:|---:|---:|---:|
| Three-run maximum | 1,269.157 ms | 1,165.354 ms | 70.182 ms | 31.526 ms | 2.095 ms |
| Three-run median | 1,266.958 ms | 1,165.253 ms | 68.882 ms | 31.153 ms | 2.062 ms |

The maximum interaction tick was 10.350 ms, below the 15 ms limit. There were
no touch overflows, crashes, or presentation failures. This is a development
characterization; final closure requires 20 reset-separated runs with normal
services and autosave enabled.

The specialized evil-hairline capacity pass now uses full progressive panel
publication and DMA completion. It measured 445.980 ms at 100% and 327.978 ms
at 400%, then passed its 448-slot saturation and repair checks.

## Bounded campaign result

All comparisons below use curved authority and the tapered-only corpus because
the combined corpus was frozen after these experiments. The effects are too
small to plausibly bridge the current combined gap, but raw logs are included.

- Four-endpoint/eight-segment conservative chunk bounds: exact, 8.5% faster
  wall, but permanently cost 200,002 bytes and missed the 15% trajectory.
- Scanline quadratic recurrence with exact boundary fallback: exact, no
  persistent bytes, 3.3% slower on device.
- Gap-free adjacent publication batching: zero resent pixels, 1.6% wall
  movement, and about 22 ms lower-zoom interaction ticks.

All candidate code was removed. Only test-harness improvements and receipts
remain. The roadmap's stop/go rule is active.

## Code map

- `source/vector_v2/src/incremental_rasterizer.cpp`: exact segment coverage and
  curved authority decomposition.
- `source/vector_v2/src/tile_producer.cpp`: newest-first exact group replay and
  bounded producer scheduling.
- `source/vector_v2/include/tinydraw/vector_v2/incremental_rasterizer.h`: curve
  replay interface.
- `source/vector_v2/include/tinydraw/vector_v2/tile_producer.h`: producer state.
- `source/vector_v2/src/incremental_document.cpp`: operation publication and
  materialized authority updates.
- `source/esp32/main/vector_v2/vector_v2_gate_harness.cpp`: device gates and
  combined corpus assembly.
- `source/vector_v2/test_support/include/tinydraw/vector_v2/adversarial_tapered_corpus.h`:
  tapered corpus generator.
- `source/vector_v2/tools/raster_census.cpp`: host exactness/census harness.
- `source/esp32/main/vector_v2/vector_v2_app.cpp`: product coordinator; noted
  maintainability debt, but refactoring it is outside this performance review.

## Raw log map

- `raw-logs/current-combined/`: three current combined-corpus baseline runs.
- `raw-logs/curved-only-baseline/`: three clean, unbatched curved-authority
  tapered-only runs used to correct experiment comparisons.
- `raw-logs/bounded-experiments/cold-segment-chunks-2.log`: final chunk-index
  candidate.
- `raw-logs/bounded-experiments/cold-raster-recurrence.log`: recurrence
  candidate.
- `raw-logs/bounded-experiments/cold-publication-batch.log`: rejected arbitrary
  batching positive failure.
- `raw-logs/bounded-experiments/cold-publication-adjacent.log`: gap-free
  adjacency candidate.

Earlier permanent pan, ink, cache, optical, and hardware receipts are included
under `source/benchmark-results/` and `source/vector_v2/hardware-receipts/`.

## Reproduction

Host prerequisites are CMake 3.28+, Ninja, and a C++20 Clang toolchain. SDL is
optional for the core test suite.

```sh
cd source
cmake --preset host-debug
cmake --build --preset host-debug --parallel 10
ctest --preset host-debug -j10
```

The packet commit passed 29/29 host-debug tests. Physical timing requires the
specified ESP32-S3 board; QEMU and host timings are not substitutes. ESP-IDF
v6.0.2 setup and device commands are documented in `source/DEVELOPING.md`.

## Integrity and exclusions

`MANIFEST.sha256` hashes every packet file except itself. The archive checksum
is supplied beside the archive. The source directory is exactly `git archive`
of the stated commit: no dirty working-tree files are included.

Two unrelated untracked owner files were intentionally excluded:
`benchmark-results/wave1a-panel/` and
`reference/CO5300_Datasheet_V0.00.pdf`.
