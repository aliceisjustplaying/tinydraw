#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <span>

#include "demo_recording.h"
#include "drawing_store.h"
#include "driver/gpio.h"
#include "esp_check.h"
#include "esp_heap_caps.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "firmware_canvas.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "image_export_store.h"
#include "physical_display.h"
#include "physical_touch.h"
#include "power_manager.h"
#include "rtc_clock.h"
#include "time_sync.h"
#include "tinydraw/demo/demo_tape.h"
#include "tinydraw/ink/ink_stream.h"
#include "tinydraw/ink/ribbon_geometry.h"
#include "tinydraw/ui/toolbar.h"
#include "usb_export.h"
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
#include "interactive_pan_benchmark.h"
#include "tinydraw/document/vector_document.h"
#endif
#ifdef TINYDRAW_PHASE2_PROTOTYPE
#include "phase2_prototype_runner.h"
#endif
#ifdef TINYDRAW_RASTER_PAN_BENCHMARK
#include "raster_pan_benchmark.h"
#endif
#ifdef TINYDRAW_VECTOR_BENCHMARK
#include "vector_benchmark_runner.h"
#endif

namespace {

constexpr std::uint16_t kBackground = 0xFFFFU;
constexpr gpio_num_t kDemoButton = GPIO_NUM_0;
constexpr std::uint32_t kDemoLongPressUs = 800'000U;
constexpr std::uint32_t kPowerRefreshUs = 1'000'000U;
constexpr std::size_t kDemoCapacity = 8192U;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
constexpr std::size_t kVectorStrokeCapacity = 1'100U;
// The realistic workload averages about 20 samples per stroke, so 1,000
// strokes plus live-draw headroom needs a deeper sample arena than the old
// fixed 12-sample workload.
constexpr std::size_t kVectorSampleCapacity = 24'576U;
#endif
using tinydraw::esp32::PhysicalTouch;
using tinydraw::esp32::TouchRead;

std::uint32_t timestamp_us() { return static_cast<std::uint32_t>(esp_timer_get_time()); }

using TouchEvent = tinydraw::DemoInputEvent;

enum class AppEventKind : std::uint8_t {
  kTouch,
  kResetForDemo,
  kDemoRecordingStarted,
  kDemoRecordingStopped,
  kDemoReplayStarted,
  kDemoReplayStopped,
  kPowerStatusChanged,
  kRefinementPublished,
};

struct AppEvent {
  TouchEvent touch{};
  tinydraw::esp32::PowerStatus power{};
  AppEventKind kind = AppEventKind::kTouch;
};

#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
void enqueue_refinement_published(void* raw) {
  auto queue = static_cast<QueueHandle_t>(raw);
  const AppEvent event{.kind = AppEventKind::kRefinementPublished};
  static_cast<void>(xQueueSend(queue, &event, 0));
}
#endif

struct TouchTaskContext {
  PhysicalTouch* touch = nullptr;
  QueueHandle_t queue = nullptr;
  tinydraw::DemoTape* tape = nullptr;
  std::span<const tinydraw::DemoSample> built_in_demo;
  tinydraw::esp32::PowerManager* power = nullptr;
  tinydraw::esp32::PowerStatus power_status{};
#ifdef TINYDRAW_PHASE2_PROTOTYPE
  tinydraw::esp32::Phase2TouchProbe* phase2_probe = nullptr;
#endif
};

void enqueue_latest(QueueHandle_t queue, const AppEvent& event) {
  if (xQueueSend(queue, &event, 0) == pdTRUE) {
    return;
  }
  AppEvent discarded;
  static_cast<void>(xQueueReceive(queue, &discarded, 0));
  static_cast<void>(xQueueSend(queue, &event, 0));
}

void enqueue_control(QueueHandle_t queue, AppEventKind kind) {
  const AppEvent event{.kind = kind};
  ESP_ERROR_CHECK(xQueueSend(queue, &event, portMAX_DELAY) == pdTRUE ? ESP_OK : ESP_FAIL);
}

void emit_touch(TouchTaskContext& context, const TouchEvent& event) {
  if (context.tape->recording()) {
    static_cast<void>(context.tape->record(event));
  }
  enqueue_latest(context.queue, {.touch = event});
}

void dump_demo(std::span<const tinydraw::DemoSample> samples, bool overflowed) {
  std::printf("TINYDRAW_DEMO_BEGIN count=%lu overflow=%u\n",
              static_cast<unsigned long>(samples.size()), overflowed);
  for (std::size_t index = 0; index < samples.size(); ++index) {
    const auto& sample = samples[index];
    std::printf("TINYDRAW_DEMO %lu %u %u %u\n", static_cast<unsigned long>(sample.offset_us),
                sample.x, sample.y, sample.touching);
    if (index % 64U == 63U) {
      vTaskDelay(pdMS_TO_TICKS(1));
    }
  }
  std::printf("TINYDRAW_DEMO_END\n");
}

void wait_for_demo_offset(std::uint32_t replay_started_us, std::uint32_t offset_us) {
  while (timestamp_us() - replay_started_us < offset_us) {
    const std::uint32_t elapsed = timestamp_us() - replay_started_us;
    const std::uint32_t remaining = offset_us - elapsed;
    if (remaining > 2'000U) {
      vTaskDelay(pdMS_TO_TICKS((remaining - 1'000U) / 1'000U));
    } else {
      esp_rom_delay_us(remaining);
    }
  }
}

void replay_demo(TouchTaskContext& context, std::span<const tinydraw::DemoSample> samples) {
  if (samples.empty()) {
    std::printf("TINYDRAW_DEMO_EMPTY\n");
    return;
  }
  xQueueReset(context.queue);
  enqueue_control(context.queue, AppEventKind::kDemoReplayStarted);
  enqueue_control(context.queue, AppEventKind::kResetForDemo);

  std::printf("TINYDRAW_DEMO_REPLAY_BEGIN count=%lu\n", static_cast<unsigned long>(samples.size()));
  const std::uint32_t replay_started_us = timestamp_us();
  for (const auto& sample : samples) {
    wait_for_demo_offset(replay_started_us, sample.offset_us);
    enqueue_latest(context.queue,
                   {.touch = tinydraw::replay_demo_sample(sample, replay_started_us)});
  }
  enqueue_control(context.queue, AppEventKind::kDemoReplayStopped);
  std::printf("TINYDRAW_DEMO_REPLAY_END\n");
}

void touch_task(void* argument) {
  auto& context = *static_cast<TouchTaskContext*>(argument);
  tinydraw::Point last_point{};
  bool touching = false;
  std::uint32_t no_touch_started_us = 0;
  bool raw_button_down = false;
  bool button_down = false;
  bool long_press_handled = false;
  std::uint32_t raw_button_changed_us = timestamp_us();
  std::uint32_t button_pressed_us = 0;
  std::uint32_t power_sampled_us = timestamp_us();
  while (true) {
    tinydraw::Point point{};
    const TouchRead read = context.touch->read(point);
    const std::uint32_t now = timestamp_us();
#ifdef TINYDRAW_PHASE2_PROTOTYPE
    if (context.phase2_probe != nullptr) {
      context.phase2_probe->record(now);
    }
#endif
    if (read == TouchRead::kPoint) {
      no_touch_started_us = 0;
      if (!touching || point.x != last_point.x || point.y != last_point.y) {
        emit_touch(context, {.point = point, .timestamp_us = now, .touching = true});
        last_point = point;
      }
      touching = true;
    } else if (read == TouchRead::kNoTouch && touching) {
      if (no_touch_started_us == 0U) {
        no_touch_started_us = now;
      } else if (now - no_touch_started_us >= 20'000U) {
        emit_touch(context, {.point = last_point, .timestamp_us = now, .touching = false});
        touching = false;
        no_touch_started_us = 0;
      }
    }

#ifndef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    const bool next_raw_button_down = gpio_get_level(kDemoButton) == 0;
    if (next_raw_button_down != raw_button_down) {
      raw_button_down = next_raw_button_down;
      raw_button_changed_us = now;
    }
    if (raw_button_down != button_down && now - raw_button_changed_us >= 25'000U) {
      button_down = raw_button_down;
      if (button_down) {
        button_pressed_us = now;
        long_press_handled = false;
      } else if (context.tape->recording()) {
        context.tape->stop_recording();
        enqueue_control(context.queue, AppEventKind::kDemoRecordingStopped);
        std::printf("TINYDRAW_DEMO_RECORDING_END count=%lu overflow=%u\n",
                    static_cast<unsigned long>(context.tape->size()), context.tape->overflowed());
        dump_demo(context.tape->samples(), context.tape->overflowed());
      } else if (!long_press_handled) {
        context.tape->begin_recording(now);
        enqueue_control(context.queue, AppEventKind::kDemoRecordingStarted);
        std::printf("TINYDRAW_DEMO_RECORDING_BEGIN capacity=%lu\n",
                    static_cast<unsigned long>(kDemoCapacity));
      }
    }
    if (button_down && !context.tape->recording() && !long_press_handled &&
        now - button_pressed_us >= kDemoLongPressUs) {
      const auto recorded = context.tape->samples();
      replay_demo(context, recorded.empty() ? context.built_in_demo : recorded);
      long_press_handled = true;
    }
#endif
    if (!touching && context.power != nullptr && context.power->ready() &&
        now - power_sampled_us >= kPowerRefreshUs) {
      const auto power_status = context.power->read();
      power_sampled_us = now;
      if (power_status.valid && power_status != context.power_status) {
        const AppEvent event{.power = power_status, .kind = AppEventKind::kPowerStatusChanged};
        if (xQueueSend(context.queue, &event, 0) == pdTRUE) {
          context.power_status = power_status;
        }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(1));
  }
}

}  // namespace

void run_hardware_app() {
  tinydraw::esp32::PhysicalDisplay display;
  PhysicalTouch touch;
  tinydraw::esp32::PowerManager power(touch.bus());
  tinydraw::esp32::RtcClock clock(touch.bus());
  if (!display.ready() || !touch.ready()) {
    std::printf("TINYDRAW_HARDWARE_FAIL display=%u touch=%u\n", display.ready(), touch.ready());
    return;
  }

  tinydraw::esp32::FirmwareCanvas canvas(display);
  if (!canvas.ready() || !canvas.capabilities_valid()) {
    std::printf("TINYDRAW_HARDWARE_FAIL canvas=0\n");
    return;
  }

#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
  auto* vector_strokes = static_cast<tinydraw::VectorStroke*>(heap_caps_malloc(
      kVectorStrokeCapacity * sizeof(tinydraw::VectorStroke), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  auto* vector_samples = static_cast<tinydraw::StrokeSample*>(heap_caps_malloc(
      kVectorSampleCapacity * sizeof(tinydraw::StrokeSample), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (vector_strokes == nullptr || vector_samples == nullptr) {
    std::printf("TINYDRAW_HARDWARE_FAIL vector_strokes=%u vector_samples=%u\n",
                vector_strokes != nullptr, vector_samples != nullptr);
    return;
  }
  tinydraw::VectorDocument vector_document(std::span(vector_strokes, kVectorStrokeCapacity),
                                           std::span(vector_samples, kVectorSampleCapacity));
  std::printf("TINYDRAW_VECTOR_READY strokes=%lu samples=%lu bytes=%lu free_psram=%lu\n",
              static_cast<unsigned long>(kVectorStrokeCapacity),
              static_cast<unsigned long>(kVectorSampleCapacity),
              static_cast<unsigned long>(kVectorStrokeCapacity * sizeof(tinydraw::VectorStroke) +
                                         kVectorSampleCapacity * sizeof(tinydraw::StrokeSample)),
              static_cast<unsigned long>(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)));
#endif
  tinydraw::esp32::DrawingStore drawing_store;
  tinydraw::esp32::ImageExportStore image_export_store;
  tinydraw::esp32::UsbExport usb_export(image_export_store);
  if (drawing_store.ready()) {
    if (!drawing_store.restore(canvas.world(), canvas.committed(), canvas.visible())) {
      std::printf("TINYDRAW_AUTOSAVE_RESTORE_FAIL\n");
    } else {
      std::printf("TINYDRAW_AUTOSAVE_READY\n");
    }
  } else {
    std::printf("TINYDRAW_AUTOSAVE_DISABLED\n");
  }
  std::printf(
      "TINYDRAW_PSRAM world_bytes=%lu free=%lu largest=%lu minimum=%lu\n",
      static_cast<unsigned long>(tinydraw::WorldCanvas::kRequiredPixels * sizeof(std::uint16_t)),
      static_cast<unsigned long>(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)),
      static_cast<unsigned long>(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM)),
      static_cast<unsigned long>(heap_caps_get_minimum_free_size(MALLOC_CAP_SPIRAM)));

  const auto initial_power_status = power.read();
  tinydraw::esp32::PowerStatus current_power_status = initial_power_status;
  tinydraw::ToolbarState toolbar;
  toolbar.can_export = image_export_store.ready();
  toolbar.battery_percentage = initial_power_status.percentage;
  toolbar.battery_charging = initial_power_status.charging;
  toolbar.external_power = initial_power_status.external_power;
  std::printf(
      "TINYDRAW_POWER_READY ready=%u button=%u valid=%u battery=%d voltage_mv=%u "
      "charging=%u vbus=%u\n",
      power.ready(), power.power_button_ready(), initial_power_status.valid,
      initial_power_status.percentage, initial_power_status.battery_mv,
      initial_power_status.charging, initial_power_status.external_power);
  display.set_toolbar(toolbar);
  display.push_canvas(canvas.committed());
#ifdef TINYDRAW_RASTER_PAN_BENCHMARK
  vTaskDelay(pdMS_TO_TICKS(500));
  tinydraw::esp32::run_raster_pan_benchmark(canvas.world(), display,
                                            tinydraw::esp32::kPhysicalMainOverlayTop);
#endif
#ifdef TINYDRAW_VECTOR_BENCHMARK
  toolbar.recording = true;
  display.set_toolbar(toolbar);
  display.refresh_toolbar(canvas.committed());
  std::printf("TINYDRAW_VECTOR_BENCH_PENDING delay_ms=1000 stack_bytes=16384\n");
  std::fflush(stdout);
  vTaskDelay(pdMS_TO_TICKS(1'000));
  // The renderer's ribbon path recurses through ~1 KiB RibbonUpdate frames and
  // overflows the 6 KiB main-task stack; give the benchmark its own task.
  {
    struct BenchmarkTask {
      std::span<std::uint16_t> destination;
      std::atomic<bool> done{false};
    } benchmark_task{.destination = canvas.visible()};
    const auto entry = [](void* raw) {
      auto* task = static_cast<BenchmarkTask*>(raw);
      tinydraw::esp32::run_vector_benchmarks(task->destination);
      task->done.store(true);
      vTaskDelete(nullptr);
    };
    if (xTaskCreatePinnedToCore(entry, "vector_bench", 16'384U, &benchmark_task, 2U, nullptr, 0) ==
        pdPASS) {
      while (!benchmark_task.done.load()) {
        vTaskDelay(pdMS_TO_TICKS(50));
      }
    } else {
      std::printf("TINYDRAW_VECTOR_BENCH_FAIL task=0\n");
    }
  }
  std::copy(canvas.committed().begin(), canvas.committed().end(), canvas.visible().begin());
  toolbar.recording = false;
  display.set_toolbar(toolbar);
  display.refresh_toolbar(canvas.committed());
#endif
#if !defined(TINYDRAW_PHASE2_PROTOTYPE) && !defined(TINYDRAW_INTERACTIVE_PAN_BENCHMARK)
  static_cast<void>(tinydraw::esp32::start_time_sync(clock));
#endif

  tinydraw::InkConfig brush;
  brush.size = tinydraw::brush_size(toolbar.size);
  tinydraw::InkStream ink(brush);
  tinydraw::CurvedRibbonStream ribbon;
  tinydraw::InkPoint last_ink{};
  tinydraw::Point last_touch{};
  std::uint16_t stroke_color = tinydraw::rgb565(toolbar.color);
  bool pressed = false;
  bool panning = false;
  bool demo_replaying = false;
  bool persistence_resync_needed = false;
  tinydraw::Point previous_saved_touch{};
  tinydraw::Point pan_start_touch{};
  tinydraw::ViewOrigin pan_start_origin{};
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
  bool vector_stroke_recording = false;
  bool vector_stroke_committed = false;
  bool vector_stroke_refused = false;
#endif
  bool toolbar_pressed = false;
  tinydraw::Point toolbar_sum{};
  std::uint32_t toolbar_samples = 0;
  std::uint32_t stroke_samples = 0;
  std::uint32_t stroke_started_us = 0;
  std::uint32_t previous_touch_us = 0;
  std::uint64_t touch_intervals_us = 0;
  std::uint32_t maximum_touch_interval_us = 0;
  std::uint32_t maximum_input_lag_us = 0;
  UBaseType_t maximum_queue_depth = 0;
  std::int64_t stroke_render_us = 0;
  std::int64_t maximum_render_us = 0;
  std::uint32_t pan_frames = 0;
  std::int64_t pan_render_us = 0;
  std::int64_t maximum_pan_render_us = 0;
  std::uint32_t export_toast_until_us = 0;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
  tinydraw::esp32::InteractivePanBenchmark* interactive_pan_benchmark = nullptr;
#endif

  const auto close_popups = [&] {
    toolbar.tools_open = false;
    toolbar.colors_open = false;
    toolbar.sizes_open = false;
  };
  const auto reset_stroke = [&] {
    ink.end();
    ribbon.reset();
    canvas.raster().cancel();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    vector_document.cancel_stroke();
    vector_stroke_recording = false;
    vector_stroke_committed = false;
    vector_stroke_refused = false;
#endif
  };
  const auto update_toolbar = [&] {
    toolbar.can_undo = canvas.undo_history().can_undo();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    if (interactive_pan_benchmark != nullptr) {
      tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
      display.set_toolbar(toolbar);
      display.refresh_toolbar_world(canvas.world().pixels(), canvas.world().origin());
      tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
    } else {
      display.set_toolbar(toolbar);
      display.refresh_toolbar(canvas.committed());
    }
#else
    display.set_toolbar(toolbar);
    display.refresh_toolbar(canvas.committed());
#endif
  };
  struct DisplayTimingSnapshot {
    std::int64_t prepare_us = 0;
    std::int64_t transfer_us = 0;
    std::uint32_t pushes = 0;
  };
  const auto reset_display_timing = [&] {
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    if (interactive_pan_benchmark != nullptr) {
      tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
      display.reset_timing();
      tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
      return;
    }
#endif
    display.reset_timing();
  };
  const auto display_timing = [&] {
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    if (interactive_pan_benchmark != nullptr) {
      tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
      const DisplayTimingSnapshot snapshot{display.prepare_us(), display.transfer_us(),
                                           display.push_count()};
      tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
      return snapshot;
    }
#endif
    return DisplayTimingSnapshot{display.prepare_us(), display.transfer_us(), display.push_count()};
  };
  const auto select_size = [&](tinydraw::PenSize size) {
    toolbar.size = size;
    auto config = ink.config();
    config.size = tinydraw::brush_size(size);
    ink.set_config(config);
    close_popups();
  };
  const auto pan_to = [&](tinydraw::Point point, std::uint32_t event_us) {
    const int delta_x = static_cast<int>(std::lround(point.x - pan_start_touch.x));
    const int delta_y = static_cast<int>(std::lround(point.y - pan_start_touch.y));
    const auto started = esp_timer_get_time();
    const tinydraw::ViewOrigin requested_origin{pan_start_origin.x - delta_x,
                                                pan_start_origin.y - delta_y};
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
    const tinydraw::ViewOrigin previous_origin = canvas.world().origin();
    if (!canvas.world().move_to(requested_origin)) {
      tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
      return;
    }
    const tinydraw::ViewOrigin actual_origin = canvas.world().origin();
    if (!tinydraw::esp32::interactive_pan_benchmark_view_changed(*interactive_pan_benchmark,
                                                                 actual_origin)) {
      static_cast<void>(canvas.world().move_to(previous_origin));
      tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
      return;
    }
#else
    if (!canvas.world().move_to(requested_origin)) {
      return;
    }
#endif
    display.push_world(canvas.world().pixels(), canvas.world().origin(),
                       tinydraw::esp32::kPhysicalMainOverlayTop);
    const auto finished = esp_timer_get_time();
    const auto elapsed = finished - started;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    // Snapshot readiness before allowing the renderer to publish another band,
    // so miss metrics describe the pixels that were actually presented.
    tinydraw::esp32::interactive_pan_benchmark_record_frame(
        *interactive_pan_benchmark, canvas.world().origin(), event_us,
        static_cast<std::uint32_t>(elapsed), static_cast<std::uint32_t>(finished) - event_us);
    tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
#endif
    ++pan_frames;
    pan_render_us += elapsed;
    maximum_pan_render_us = std::max(maximum_pan_render_us, elapsed);
  };
  const auto new_drawing = [&] {
    reset_stroke();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    vector_document.clear();
    vector_stroke_recording = false;
#endif
    canvas.undo_history().begin_entry(canvas.world().origin());
    canvas.undo_history().capture_canvas(canvas.committed());
    static_cast<void>(canvas.undo_history().commit_entry());
    static_cast<void>(canvas.world().clear(canvas.committed(), canvas.visible()));
    toolbar.export_ready = false;
    toolbar.confirm_new = false;
    close_popups();
    toolbar.can_undo = canvas.undo_history().can_undo();
    display.set_toolbar(toolbar);
    display.push_canvas(canvas.committed());
    if (!demo_replaying) {
      drawing_store.save_all(canvas.world());
      persistence_resync_needed = false;
    }
  };
  const auto reset_for_demo = [&] {
    reset_stroke();
    pressed = false;
    panning = false;
    toolbar_pressed = false;
    toolbar_samples = 0;
    toolbar = {};
    toolbar.can_export = image_export_store.ready();
    toolbar.battery_percentage = current_power_status.percentage;
    toolbar.battery_charging = current_power_status.charging;
    toolbar.external_power = current_power_status.external_power;
    auto config = ink.config();
    config.size = tinydraw::brush_size(toolbar.size);
    ink.set_config(config);
    stroke_color = tinydraw::rgb565(toolbar.color);
    canvas.undo_history().clear();
    static_cast<void>(canvas.world().clear(canvas.committed(), canvas.visible()));
    display.set_toolbar(toolbar);
    display.push_canvas(canvas.committed());
  };
  const auto undo = [&] {
    if (!canvas.undo_history().can_undo()) {
      return;
    }
    reset_stroke();
    reset_display_timing();
    const auto started = esp_timer_get_time();
    static_cast<void>(canvas.world().capture(canvas.committed()));
    const auto undo_origin = canvas.undo_history().next_undo_origin();
    const bool view_changed = undo_origin.has_value() && *undo_origin != canvas.world().origin();
    if (view_changed) {
      static_cast<void>(canvas.world().show(*undo_origin, canvas.committed(), canvas.visible()));
    }
    const auto stats = canvas.undo_history().undo(canvas.committed(), canvas.visible(),
                                                  view_changed ? nullptr : &display);
    static_cast<void>(canvas.world().capture(canvas.committed()));
    close_popups();
    toolbar.export_ready = false;
    toolbar.can_undo = canvas.undo_history().can_undo();
    display.set_toolbar(toolbar);
    if (view_changed) {
      display.push_canvas(canvas.committed());
    } else {
      display.refresh_toolbar(canvas.committed());
    }
    if (!demo_replaying) {
      if (persistence_resync_needed) {
        drawing_store.save_all(canvas.world());
      } else {
        drawing_store.save_viewport(canvas.world(), canvas.committed());
      }
      persistence_resync_needed = false;
    }
    const DisplayTimingSnapshot timing = display_timing();
    std::printf(
        "[DEBUG-undo1] tiles=%lu bytes=%lu view_changed=%u elapsed_us=%lld prepare_us=%lld "
        "transfer_us=%lld pushes=%lu\n",
        static_cast<unsigned long>(stats.tiles_restored),
        static_cast<unsigned long>(stats.display_bytes), view_changed,
        static_cast<long long>(esp_timer_get_time() - started),
        static_cast<long long>(timing.prepare_us), static_cast<long long>(timing.transfer_us),
        static_cast<unsigned long>(timing.pushes));
  };
  const auto export_image = [&] {
    reset_stroke();
    usb_export.prepare_export();
    tinydraw::FatDateTime modified_time;
    if (clock.read(modified_time)) {
      usb_export.set_modified_time(modified_time);
    }
    static_cast<void>(canvas.world().capture(canvas.committed()));
    toolbar.exporting = true;
    toolbar.export_ready = false;
    toolbar.export_toast = true;
    close_popups();
    update_toolbar();
    vTaskDelay(pdMS_TO_TICKS(20));
    const auto stats = image_export_store.encode(canvas.world().pixels());
    std::printf("TINYDRAW_EXPORT success=%u bytes=%lu elapsed_us=%lld free_psram=%lu\n",
                stats.success, static_cast<unsigned long>(stats.bytes),
                static_cast<long long>(stats.elapsed_us),
                static_cast<unsigned long>(stats.free_psram));
    std::fflush(stdout);
    const bool usb_ready = usb_export.finish_export(stats.success);
    toolbar.exporting = false;
    toolbar.export_ready = stats.success && usb_ready;
    toolbar.export_toast = true;
    export_toast_until_us = timestamp_us() + 3'000'000U;
    close_popups();
    update_toolbar();
  };
  const auto toolbar_action = [&](tinydraw::Point point) {
    const auto action = tinydraw::toolbar_action_at(point, toolbar);
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
    if (action == tinydraw::ToolbarAction::kSelectSmall ||
        action == tinydraw::ToolbarAction::kSelectMedium ||
        action == tinydraw::ToolbarAction::kSelectLarge) {
      const int zoom_percent = action == tinydraw::ToolbarAction::kSelectSmall    ? 50
                               : action == tinydraw::ToolbarAction::kSelectMedium ? 100
                                                                                  : 200;
      toolbar.size = action == tinydraw::ToolbarAction::kSelectSmall    ? tinydraw::PenSize::kSmall
                     : action == tinydraw::ToolbarAction::kSelectMedium ? tinydraw::PenSize::kMedium
                                                                        : tinydraw::PenSize::kLarge;
      close_popups();
      const bool zoom_changed = tinydraw::esp32::interactive_pan_benchmark_set_zoom(
          *interactive_pan_benchmark, zoom_percent);
      if (!zoom_changed) {
        std::printf("TINYDRAW_INTERACTIVE_PAN_FAIL zoom=%d\n", zoom_percent);
      }
      // set_zoom presents the transition itself as center-out strips.
      update_toolbar();
      return;
    }
    if (action == tinydraw::ToolbarAction::kSelectExtraLarge) {
      close_popups();
      toolbar.recording = false;
      static_cast<void>(
          tinydraw::esp32::finish_interactive_pan_benchmark(*interactive_pan_benchmark));
      update_toolbar();
      return;
    }
    // Pen and pan remain available so the same materialized document can be
    // mutated and exercised. Other production actions stay outside this
    // throwaway prototype.
    if (action != tinydraw::ToolbarAction::kToggleSizes &&
        action != tinydraw::ToolbarAction::kToggleTools &&
        action != tinydraw::ToolbarAction::kSelectPen &&
        action != tinydraw::ToolbarAction::kSelectPan &&
        action != tinydraw::ToolbarAction::kSelectEraser &&
        action != tinydraw::ToolbarAction::kToggleColors &&
        action != tinydraw::ToolbarAction::kSelectColor &&
        action != tinydraw::ToolbarAction::kNone) {
      close_popups();
      update_toolbar();
      return;
    }
#endif
    switch (action) {
      case tinydraw::ToolbarAction::kSelectPen:
        toolbar.tool = tinydraw::DrawingTool::kPen;
        close_popups();
        break;
      case tinydraw::ToolbarAction::kSelectPan:
        toolbar.tool = tinydraw::DrawingTool::kPan;
        close_popups();
        break;
      case tinydraw::ToolbarAction::kSelectEraser:
        toolbar.tool = tinydraw::DrawingTool::kEraser;
        close_popups();
        break;
      case tinydraw::ToolbarAction::kSelectColor:
        toolbar.color = tinydraw::toolbar_color_at(point, toolbar).value_or(toolbar.color);
        toolbar.tool = tinydraw::DrawingTool::kPen;
        close_popups();
        break;
      case tinydraw::ToolbarAction::kToggleTools:
        toolbar.tools_open = !toolbar.tools_open;
        toolbar.colors_open = false;
        toolbar.sizes_open = false;
        break;
      case tinydraw::ToolbarAction::kToggleColors:
        toolbar.colors_open = !toolbar.colors_open;
        toolbar.tools_open = false;
        toolbar.sizes_open = false;
        break;
      case tinydraw::ToolbarAction::kToggleSizes:
        toolbar.sizes_open = !toolbar.sizes_open;
        toolbar.tools_open = false;
        toolbar.colors_open = false;
        break;
      case tinydraw::ToolbarAction::kSelectSmall:
        select_size(tinydraw::PenSize::kSmall);
        break;
      case tinydraw::ToolbarAction::kSelectMedium:
        select_size(tinydraw::PenSize::kMedium);
        break;
      case tinydraw::ToolbarAction::kSelectLarge:
        select_size(tinydraw::PenSize::kLarge);
        break;
      case tinydraw::ToolbarAction::kSelectExtraLarge:
        select_size(tinydraw::PenSize::kExtraLarge);
        break;
      case tinydraw::ToolbarAction::kExport:
        export_image();
        return;
      case tinydraw::ToolbarAction::kUndo:
        undo();
        return;
      case tinydraw::ToolbarAction::kNewDrawing:
        close_popups();
        toolbar.confirm_new = true;
        break;
      case tinydraw::ToolbarAction::kCancelNewDrawing:
        toolbar.confirm_new = false;
        break;
      case tinydraw::ToolbarAction::kConfirmNewDrawing:
        new_drawing();
        return;
      case tinydraw::ToolbarAction::kNone:
        break;
    }
    update_toolbar();
  };

  auto* demo_storage = static_cast<tinydraw::DemoSample*>(heap_caps_malloc(
      kDemoCapacity * sizeof(tinydraw::DemoSample), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  QueueHandle_t touch_queue = xQueueCreate(32U, sizeof(AppEvent));
  if (demo_storage == nullptr || touch_queue == nullptr) {
    std::printf("TINYDRAW_HARDWARE_FAIL demo_storage=%u touch_queue=%u\n", demo_storage != nullptr,
                touch_queue != nullptr);
    return;
  }
  tinydraw::DemoTape demo_tape(std::span(demo_storage, kDemoCapacity));
  gpio_config_t demo_button_config{};
  demo_button_config.pin_bit_mask = 1ULL << static_cast<unsigned>(kDemoButton);
  demo_button_config.mode = GPIO_MODE_INPUT;
  demo_button_config.pull_up_en = GPIO_PULLUP_ENABLE;
  ESP_ERROR_CHECK(gpio_config(&demo_button_config));

#ifdef TINYDRAW_PHASE2_PROTOTYPE
  tinydraw::esp32::Phase2TouchProbe phase2_touch_probe;
#endif
  TouchTaskContext touch_context{
      .touch = &touch,
      .queue = touch_queue,
      .tape = &demo_tape,
      .built_in_demo = tinydraw::esp32::demo::kBuiltInDemo,
      .power = &power,
      .power_status = initial_power_status,
#ifdef TINYDRAW_PHASE2_PROTOTYPE
      .phase2_probe = &phase2_touch_probe,
#endif
  };
  if (xTaskCreatePinnedToCore(touch_task, "tinydraw_touch", 4096U, &touch_context, 5U, nullptr,
                              1) != pdPASS) {
    std::printf("TINYDRAW_HARDWARE_FAIL touch_task=0\n");
    return;
  }

#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
  drawing_store.suspend();
  toolbar.tool = tinydraw::DrawingTool::kPan;
  toolbar.size = tinydraw::PenSize::kMedium;
  toolbar.recording = true;
  close_popups();
  display.set_toolbar(toolbar);
  display.refresh_toolbar(canvas.committed());
  const std::int64_t benchmark_init_started = esp_timer_get_time();
  interactive_pan_benchmark = tinydraw::esp32::start_interactive_pan_benchmark(
      vector_document, canvas.world(), canvas.prototype_materialization_storage(), canvas.visible(),
      tinydraw::esp32::kPhysicalMainOverlayTop, display, enqueue_refinement_published, touch_queue,
      {.submit_count = tinydraw::esp32::physical_display_submit_count,
       .complete_count = tinydraw::esp32::physical_display_complete_count,
       .complete_time_us = tinydraw::esp32::physical_display_complete_time_us,
       .context = &display});
  if (interactive_pan_benchmark == nullptr) {
    std::printf("TINYDRAW_HARDWARE_FAIL interactive_pan_benchmark=0\n");
    return;
  }
  xQueueReset(touch_queue);
  tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
  display.push_world(canvas.world().pixels(), canvas.world().origin(),
                     tinydraw::esp32::kPhysicalMainOverlayTop);
  tinydraw::esp32::interactive_pan_benchmark_record_zoom_present(*interactive_pan_benchmark);
  tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
  std::printf("TINYDRAW_INTERACTIVE_PAN_READY zoom=100 controls=S:50 M:100 L:200 XL:finish\n");
  std::printf("TINYDRAW_AUTO_INIT initial_atlas_us=%lld\n",
              static_cast<long long>(esp_timer_get_time() - benchmark_init_started));
  // Hands-free A/B zoom driver: exercises the same set_zoom -> push_world ->
  // record_zoom_present path the toolbar uses, without touch input, and prints
  // driver-side wall times so baseline and patched firmware are comparable
  // regardless of internal metric definitions.
  {
    constexpr std::array<int, 12> kAutoZoomSequence{50,  100, 200, 100, 50,  100,
                                                    200, 100, 50,  100, 200, 100};
    std::fflush(stdout);
    vTaskDelay(pdMS_TO_TICKS(2'000));
    for (std::size_t cycle = 0; cycle < kAutoZoomSequence.size(); ++cycle) {
      const int percent = kAutoZoomSequence[cycle];
      const std::int64_t auto_zoom_started = esp_timer_get_time();
      const bool changed =
          tinydraw::esp32::interactive_pan_benchmark_set_zoom(*interactive_pan_benchmark, percent);
      const std::int64_t auto_zoom_returned = esp_timer_get_time();
      tinydraw::esp32::ZoomTransitionTiming timing;
      if (changed && tinydraw::esp32::interactive_pan_benchmark_last_zoom_timing(
                         *interactive_pan_benchmark, percent, timing)) {
        std::printf(
            "TINYDRAW_AUTO_ZOOM cycle=%u zoom=%d changed=1 total_us=%lld cancel_us=%lu "
            "first_ready_us=%lu first_submit_us=%lu first_complete_us=%lu last_submit_us=%lu "
            "last_complete_us=%lu fallback_us=%lu settled_us=%lu\n",
            static_cast<unsigned>(cycle), percent,
            static_cast<long long>(auto_zoom_returned - auto_zoom_started),
            static_cast<unsigned long>(timing.cancel_done_us),
            static_cast<unsigned long>(timing.first_strip_ready_us),
            static_cast<unsigned long>(timing.first_strip_submit_us),
            static_cast<unsigned long>(timing.first_strip_complete_us),
            static_cast<unsigned long>(timing.last_visible_submit_us),
            static_cast<unsigned long>(timing.last_visible_complete_us),
            static_cast<unsigned long>(timing.fallback_ready_us),
            static_cast<unsigned long>(timing.settled_us));
      } else {
        std::printf("TINYDRAW_AUTO_ZOOM cycle=%u zoom=%d changed=0 total_us=%lld\n",
                    static_cast<unsigned>(cycle), percent,
                    static_cast<long long>(auto_zoom_returned - auto_zoom_started));
      }
      std::fflush(stdout);
      if (changed) {
        const tinydraw::ViewOrigin zoom_origin{tinydraw::kCanvasWidth, tinydraw::kCanvasHeight};
        const bool down_ready = tinydraw::esp32::interactive_pan_benchmark_view_ready(
            *interactive_pan_benchmark, {zoom_origin.x, zoom_origin.y + 12});
        const std::int64_t runway_started = esp_timer_get_time();
        bool right_ready = tinydraw::esp32::interactive_pan_benchmark_view_ready(
            *interactive_pan_benchmark, {zoom_origin.x + 1, zoom_origin.y});
        while (!right_ready && esp_timer_get_time() - runway_started < 1'000'000) {
          vTaskDelay(pdMS_TO_TICKS(1));
          right_ready = tinydraw::esp32::interactive_pan_benchmark_view_ready(
              *interactive_pan_benchmark, {zoom_origin.x + 1, zoom_origin.y});
        }
        std::printf(
            "TINYDRAW_AUTO_RUNWAY cycle=%u zoom=%d down12_ready=%u right1_ready=%u "
            "right1_ready_us=%lld\n",
            static_cast<unsigned>(cycle), percent, down_ready, right_ready,
            static_cast<long long>(esp_timer_get_time() - runway_started));
        std::fflush(stdout);
      }
      // Poll for the background visible-settled pass within the settling gap.
      if (changed) {
        const std::int64_t settle_deadline = esp_timer_get_time() + 4'500'000;
        while (timing.settled_us == 0U && esp_timer_get_time() < settle_deadline) {
          vTaskDelay(pdMS_TO_TICKS(5));
          if (!tinydraw::esp32::interactive_pan_benchmark_last_zoom_timing(
                  *interactive_pan_benchmark, percent, timing)) {
            break;
          }
        }
        std::printf("TINYDRAW_AUTO_SETTLED cycle=%u zoom=%d settled_us=%lu\n",
                    static_cast<unsigned>(cycle), percent,
                    static_cast<unsigned long>(timing.settled_us));
        std::fflush(stdout);
      }
      vTaskDelay(pdMS_TO_TICKS(500));
    }
    // Exercise the post-mutation provenance path without requiring touch:
    // zoom must refuse while the pinned source is stale, then recover after
    // incremental exact repair of the affected source bands.
    const bool mutation_started =
        tinydraw::esp32::interactive_pan_benchmark_begin_stroke(*interactive_pan_benchmark);
    const auto mutation_start = tinydraw::esp32::interactive_pan_benchmark_map_sample(
        *interactive_pan_benchmark, {.x = 80.0F, .y = 180.0F}, 3.0F);
    const auto mutation_end = tinydraw::esp32::interactive_pan_benchmark_map_sample(
        *interactive_pan_benchmark, {.x = 288.0F, .y = 190.0F}, 3.0F);
    const bool mutation_committed =
        mutation_started &&
        vector_document.begin_stroke(0x07E0U, tinydraw::VectorTool::kPen, mutation_start) &&
        vector_document.append(mutation_end) && vector_document.finish_stroke();
    if (mutation_committed) {
      tinydraw::esp32::interactive_pan_benchmark_commit_stroke(*interactive_pan_benchmark, false);
    } else {
      vector_document.cancel_stroke();
      tinydraw::esp32::interactive_pan_benchmark_cancel_stroke(*interactive_pan_benchmark);
    }
    const bool accepted_while_stale =
        mutation_committed &&
        tinydraw::esp32::interactive_pan_benchmark_set_zoom(*interactive_pan_benchmark, 50);
    vTaskDelay(pdMS_TO_TICKS(3'000));
    const bool accepted_after_repair =
        mutation_committed &&
        tinydraw::esp32::interactive_pan_benchmark_set_zoom(*interactive_pan_benchmark, 50);
    std::printf(
        "TINYDRAW_AUTO_MUTATION started=%u committed=%u stale_zoom_accepted=%u "
        "repaired_zoom_accepted=%u\n",
        mutation_started, mutation_committed, accepted_while_stale, accepted_after_repair);

    // Keep the automated hardware run honest: completion metrics alone cannot
    // distinguish rendered ink from a successfully published white buffer.
    // Record both atlas and visible content, then republish the final viewport
    // so a later panel overwrite is visually distinguishable from bad raster data.
    tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
    const auto final_world = canvas.world().pixels();
    const auto final_origin = canvas.world().origin();
    std::size_t atlas_ink_pixels = 0U;
    std::size_t visible_ink_pixels = 0U;
    std::uint32_t visible_hash = 2166136261U;
    for (int y = 0; y < tinydraw::WorldCanvas::kHeight; ++y) {
      for (int x = 0; x < tinydraw::WorldCanvas::kWidth; ++x) {
        atlas_ink_pixels +=
            final_world[static_cast<std::size_t>(y * tinydraw::WorldCanvas::kWidth + x)] !=
            kBackground;
      }
    }
    for (int y = 0; y < tinydraw::esp32::kPhysicalMainOverlayTop; ++y) {
      const auto row = static_cast<std::size_t>(
          (final_origin.y + y) * tinydraw::WorldCanvas::kWidth + final_origin.x);
      for (int x = 0; x < tinydraw::kCanvasWidth; ++x) {
        const std::uint16_t pixel = final_world[row + static_cast<std::size_t>(x)];
        visible_ink_pixels += pixel != kBackground;
        visible_hash = (visible_hash ^ pixel) * 16777619U;
      }
    }
    std::printf(
        "TINYDRAW_AUTO_FINAL_PIXELS origin=%d,%d atlas_ink=%lu visible_ink=%lu "
        "visible_hash=%08lx\n",
        final_origin.x, final_origin.y, static_cast<unsigned long>(atlas_ink_pixels),
        static_cast<unsigned long>(visible_ink_pixels), static_cast<unsigned long>(visible_hash));
    display.push_world(final_world, final_origin, tinydraw::esp32::kPhysicalMainOverlayTop);
    tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
    std::printf("TINYDRAW_AUTO_ZOOM_DONE\n");
    std::fflush(stdout);
  }
#endif

#ifdef TINYDRAW_PHASE2_PROTOTYPE
  toolbar.recording = true;
  display.set_toolbar(toolbar);
  display.refresh_toolbar(canvas.committed());
  std::printf("TINYDRAW_PHASE2_PENDING delay_ms=1000 stack_bytes=16384\n");
  std::fflush(stdout);
  vTaskDelay(pdMS_TO_TICKS(1'000));
  {
    struct PrototypeTask {
      std::span<std::uint16_t> cache;
      std::span<std::uint16_t> reference;
      tinydraw::DisplayBackend* display = nullptr;
      tinydraw::esp32::Phase2TouchProbe* touch_probe = nullptr;
      std::atomic<bool> done{false};
    } prototype_task{
        .cache = canvas.visible(),
        .reference = canvas.committed(),
        .display = &display,
        .touch_probe = &phase2_touch_probe,
    };
    const auto entry = [](void* raw) {
      auto* task = static_cast<PrototypeTask*>(raw);
      tinydraw::esp32::run_phase2_prototype(task->cache, task->reference, *task->display,
                                            *task->touch_probe);
      task->done.store(true);
      vTaskDelete(nullptr);
    };
    if (xTaskCreatePinnedToCore(entry, "phase2_proto", 16'384U, &prototype_task, 2U, nullptr, 0) ==
        pdPASS) {
      while (!prototype_task.done.load()) {
        vTaskDelay(pdMS_TO_TICKS(50));
      }
    } else {
      std::printf("TINYDRAW_PHASE2_FAIL task=0\n");
    }
  }
  xQueueReset(touch_queue);
  static_cast<void>(
      canvas.world().show(canvas.world().origin(), canvas.committed(), canvas.visible()));
  toolbar.recording = false;
  display.set_toolbar(toolbar);
  display.push_canvas(canvas.committed());
  static_cast<void>(tinydraw::esp32::start_time_sync(clock));
#endif

  std::printf("TINYDRAW_HARDWARE_OK display=CO5300 touch=CST820 demo_capacity=%lu\n",
              static_cast<unsigned long>(kDemoCapacity));
  while (true) {
    if (toolbar.export_toast &&
        static_cast<std::int32_t>(timestamp_us() - export_toast_until_us) >= 0) {
      toolbar.export_toast = false;
      update_toolbar();
    }
    AppEvent app_event;
    const TickType_t wait = toolbar.export_toast ? pdMS_TO_TICKS(50) : portMAX_DELAY;
    if (xQueueReceive(touch_queue, &app_event, wait) != pdTRUE) {
      continue;
    }
    if (app_event.kind == AppEventKind::kDemoReplayStarted ||
        app_event.kind == AppEventKind::kDemoReplayStopped) {
      demo_replaying = app_event.kind == AppEventKind::kDemoReplayStarted;
      if (demo_replaying) {
        drawing_store.suspend();
      } else {
        persistence_resync_needed = true;
      }
      continue;
    }
    if (app_event.kind == AppEventKind::kResetForDemo) {
      reset_for_demo();
      continue;
    }
    if (app_event.kind == AppEventKind::kRefinementPublished) {
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
      update_toolbar();
#endif
      continue;
    }
    if (app_event.kind == AppEventKind::kPowerStatusChanged) {
      current_power_status = app_event.power;
      toolbar.battery_percentage = current_power_status.percentage;
      toolbar.battery_charging = current_power_status.charging;
      toolbar.external_power = current_power_status.external_power;
      update_toolbar();
      std::printf("TINYDRAW_POWER battery=%d voltage_mv=%u charging=%u vbus=%u\n",
                  current_power_status.percentage, current_power_status.battery_mv,
                  current_power_status.charging, current_power_status.external_power);
      continue;
    }
    if (app_event.kind == AppEventKind::kDemoRecordingStarted ||
        app_event.kind == AppEventKind::kDemoRecordingStopped) {
      toolbar.recording = app_event.kind == AppEventKind::kDemoRecordingStarted;
      update_toolbar();
      continue;
    }
    TouchEvent event = app_event.touch;
    if (toolbar.export_toast) {
      toolbar.export_toast = false;
      update_toolbar();
    }
    if (panning && event.touching) {
      AppEvent latest;
      while (xQueuePeek(touch_queue, &latest, 0) == pdTRUE && latest.kind == AppEventKind::kTouch) {
        static_cast<void>(xQueueReceive(touch_queue, &latest, 0));
        event = latest.touch;
        if (!event.touching) {
          break;
        }
      }
    }
    const tinydraw::Point point = event.point;
    const bool touching = event.touching;
    if (!demo_replaying) {
      drawing_store.activity();
    }
    const std::uint32_t input_lag_us = timestamp_us() - event.timestamp_us;
    const UBaseType_t queue_depth = uxQueueMessagesWaiting(touch_queue);
    if (touching && !pressed) {
      std::printf("[DEBUG-hw1] down x=%.0f y=%.0f\n", static_cast<double>(point.x),
                  static_cast<double>(point.y));
      pressed = true;
      last_touch = point;
      if (toolbar.confirm_new) {
        const auto action = tinydraw::toolbar_action_at(point, toolbar);
        if (action == tinydraw::ToolbarAction::kCancelNewDrawing ||
            action == tinydraw::ToolbarAction::kConfirmNewDrawing) {
          toolbar_action(point);
          continue;
        }
      }
      if (tinydraw::toolbar_contains(point, toolbar)) {
        toolbar_pressed = true;
        toolbar_sum = point;
        toolbar_samples = 1;
      } else {
        close_popups();
        if (toolbar.tool == tinydraw::DrawingTool::kPan) {
#ifndef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
          static_cast<void>(canvas.world().capture(canvas.committed()));
#endif
          pan_start_touch = point;
          pan_start_origin = canvas.world().origin();
          pan_frames = 0;
          pan_render_us = 0;
          maximum_pan_render_us = 0;
          reset_display_timing();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
          tinydraw::esp32::interactive_pan_benchmark_begin_pan(
              *interactive_pan_benchmark, pan_start_origin, event.timestamp_us);
#endif
          panning = true;
          continue;
        }
        stroke_color = toolbar.tool == tinydraw::DrawingTool::kEraser
                           ? kBackground
                           : tinydraw::rgb565(toolbar.color);
        previous_saved_touch = point;
        if (!demo_replaying) {
          drawing_store.include_segment(point, point, ink.config().size + 4.0F,
                                        canvas.world().origin());
        }
        last_ink = ink.begin({.x = point.x, .y = point.y, .timestamp_us = event.timestamp_us});
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        const bool mutation_ready =
            tinydraw::esp32::interactive_pan_benchmark_begin_stroke(*interactive_pan_benchmark);
        const auto first_vector_sample = tinydraw::esp32::interactive_pan_benchmark_map_sample(
            *interactive_pan_benchmark, last_ink.position, last_ink.radius);
        vector_stroke_recording =
            !demo_replaying && mutation_ready &&
            vector_document.begin_stroke(stroke_color,
                                         toolbar.tool == tinydraw::DrawingTool::kEraser
                                             ? tinydraw::VectorTool::kEraser
                                             : tinydraw::VectorTool::kPen,
                                         first_vector_sample);
        if (mutation_ready && !vector_stroke_recording) {
          tinydraw::esp32::interactive_pan_benchmark_cancel_stroke(*interactive_pan_benchmark);
        }
        vector_stroke_committed = false;
        vector_stroke_refused = !vector_stroke_recording;
        if (vector_stroke_recording) {
          tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
          static_cast<void>(
              canvas.world().show(canvas.world().origin(), canvas.committed(), canvas.visible()));
          tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
        }
#endif
        stroke_samples = 1;
        stroke_started_us = event.timestamp_us;
        previous_touch_us = event.timestamp_us;
        touch_intervals_us = 0;
        maximum_touch_interval_us = 0;
        maximum_input_lag_us = input_lag_us;
        maximum_queue_depth = queue_depth;
        stroke_render_us = 0;
        maximum_render_us = 0;
        reset_display_timing();
        const auto started = esp_timer_get_time();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        if (!vector_stroke_refused)
#endif
        {
          static_cast<void>(canvas.raster().update(ribbon.append(last_ink), stroke_color));
        }
        const auto elapsed = esp_timer_get_time() - started;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        tinydraw::esp32::interactive_pan_benchmark_record_draw_update(
            *interactive_pan_benchmark, static_cast<std::uint32_t>(elapsed));
#endif
        stroke_render_us += elapsed;
        maximum_render_us = std::max(maximum_render_us, elapsed);
      }
    } else if (touching && pressed && toolbar_pressed &&
               (point.x != last_touch.x || point.y != last_touch.y)) {
      last_touch = point;
      if (tinydraw::toolbar_contains(point, toolbar)) {
        toolbar_sum.x += point.x;
        toolbar_sum.y += point.y;
        ++toolbar_samples;
      }
    } else if (touching && pressed && panning &&
               (point.x != last_touch.x || point.y != last_touch.y)) {
      last_touch = point;
      pan_to(point, event.timestamp_us);
    } else if (touching && pressed && ink.active() &&
               (point.x != last_touch.x || point.y != last_touch.y)) {
      last_touch = point;
      if (!demo_replaying) {
        drawing_store.include_segment(previous_saved_touch, point, ink.config().size + 4.0F,
                                      canvas.world().origin());
      }
      previous_saved_touch = point;
      last_ink = ink.update({.x = point.x, .y = point.y, .timestamp_us = event.timestamp_us});
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
      const auto vector_sample = tinydraw::esp32::interactive_pan_benchmark_map_sample(
          *interactive_pan_benchmark, last_ink.position, last_ink.radius);
      if (vector_stroke_recording && !vector_document.append(vector_sample)) {
        vector_document.cancel_stroke();
        vector_stroke_recording = false;
        vector_stroke_refused = true;
        std::printf("TINYDRAW_VECTOR_FULL strokes=%lu samples=%lu\n",
                    static_cast<unsigned long>(vector_document.stroke_count()),
                    static_cast<unsigned long>(vector_document.sample_count()));
      }
#endif
      const std::uint32_t touch_interval_us = event.timestamp_us - previous_touch_us;
      previous_touch_us = event.timestamp_us;
      touch_intervals_us += touch_interval_us;
      maximum_touch_interval_us = std::max(maximum_touch_interval_us, touch_interval_us);
      ++stroke_samples;
      maximum_input_lag_us = std::max(maximum_input_lag_us, input_lag_us);
      maximum_queue_depth = std::max(maximum_queue_depth, queue_depth);
      const auto started = esp_timer_get_time();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
      if (!vector_stroke_refused)
#endif
      {
        static_cast<void>(canvas.raster().update(ribbon.append(last_ink), stroke_color));
      }
      const auto elapsed = esp_timer_get_time() - started;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
      tinydraw::esp32::interactive_pan_benchmark_record_draw_update(
          *interactive_pan_benchmark, static_cast<std::uint32_t>(elapsed));
#endif
      stroke_render_us += elapsed;
      maximum_render_us = std::max(maximum_render_us, elapsed);
    } else if (!touching && pressed) {
      pressed = false;
      if (toolbar_pressed) {
        toolbar_pressed = false;
        const float divisor = static_cast<float>(toolbar_samples == 0 ? 1 : toolbar_samples);
        const tinydraw::Point tap{.x = toolbar_sum.x / divisor, .y = toolbar_sum.y / divisor};
        toolbar_samples = 0;
        if (tinydraw::toolbar_contains(tap, toolbar)) {
          toolbar_action(tap);
        }
        continue;
      }
      if (panning) {
        pan_to(point, event.timestamp_us);
        panning = false;
        std::int64_t settle_us = 0;
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        tinydraw::esp32::interactive_pan_benchmark_end_pan(*interactive_pan_benchmark);
#else
        const auto settle_started = esp_timer_get_time();
        static_cast<void>(
            canvas.world().show(canvas.world().origin(), canvas.committed(), canvas.visible()));
        settle_us = esp_timer_get_time() - settle_started;
        if (!demo_replaying && !persistence_resync_needed) {
          drawing_store.save_origin(canvas.world());
        }
#endif
        const auto bytes = static_cast<std::uint64_t>(pan_frames) * tinydraw::kCanvasWidth *
                           tinydraw::esp32::kPhysicalMainOverlayTop * sizeof(std::uint16_t);
        const DisplayTimingSnapshot timing = display_timing();
        std::printf(
            "TINYDRAW_PAN_PERF frames=%lu bytes=%llu average_us=%lld max_us=%lld "
            "settle_us=%lld prepare_us=%lld transfer_us=%lld pushes=%lu\n",
            static_cast<unsigned long>(pan_frames), static_cast<unsigned long long>(bytes),
            static_cast<long long>(pan_frames == 0 ? 0 : pan_render_us / pan_frames),
            static_cast<long long>(maximum_pan_render_us), static_cast<long long>(settle_us),
            static_cast<long long>(timing.prepare_us), static_cast<long long>(timing.transfer_us),
            static_cast<unsigned long>(timing.pushes));
        continue;
      }
      if (ink.active()) {
        last_ink =
            ink.finish({.x = last_touch.x, .y = last_touch.y, .timestamp_us = event.timestamp_us});
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        if (vector_stroke_recording) {
          const auto final_vector_sample = tinydraw::esp32::interactive_pan_benchmark_map_sample(
              *interactive_pan_benchmark, last_ink.position, last_ink.radius);
          if (vector_document.append(final_vector_sample) && vector_document.finish_stroke()) {
            vector_stroke_committed = true;
            std::printf("TINYDRAW_VECTOR_STROKE strokes=%lu samples=%lu\n",
                        static_cast<unsigned long>(vector_document.stroke_count()),
                        static_cast<unsigned long>(vector_document.sample_count()));
          } else {
            vector_document.cancel_stroke();
            std::printf("TINYDRAW_VECTOR_FULL strokes=%lu samples=%lu\n",
                        static_cast<unsigned long>(vector_document.stroke_count()),
                        static_cast<unsigned long>(vector_document.sample_count()));
          }
          vector_stroke_recording = false;
        }
#endif
        const auto started = esp_timer_get_time();
#ifdef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        if (vector_stroke_refused || !vector_stroke_committed) {
          canvas.raster().cancel();
          tinydraw::esp32::interactive_pan_benchmark_cancel_stroke(*interactive_pan_benchmark);
        } else {
          // Raster Undo owns the prototype's inactive atlas arena, so it must
          // not participate in this deliberately history-free benchmark.
          static_cast<void>(canvas.raster().finish(ribbon.finish(last_ink), stroke_color, nullptr,
                                                   canvas.world().origin()));
          tinydraw::esp32::interactive_pan_benchmark_lock_cache(*interactive_pan_benchmark);
          static_cast<void>(canvas.world().capture(canvas.committed()));
          tinydraw::esp32::interactive_pan_benchmark_unlock_cache(*interactive_pan_benchmark);
          tinydraw::esp32::interactive_pan_benchmark_commit_stroke(*interactive_pan_benchmark,
                                                                   true);
        }
#else
        static_cast<void>(canvas.raster().finish(ribbon.finish(last_ink), stroke_color,
                                                 &canvas.undo_history(), canvas.world().origin()));
#endif
        const auto finish_us = esp_timer_get_time() - started;
        const DisplayTimingSnapshot timing = display_timing();
        toolbar.export_ready = false;
#ifndef TINYDRAW_INTERACTIVE_PAN_BENCHMARK
        if (!demo_replaying) {
          if (persistence_resync_needed) {
            static_cast<void>(canvas.world().capture(canvas.committed()));
            drawing_store.save_all(canvas.world());
          } else {
            drawing_store.save_stroke(canvas.world(), canvas.committed());
          }
          persistence_resync_needed = false;
        }
#endif
        std::printf(
            "[DEBUG-perf1] samples=%lu updates_us=%lld average_us=%lld max_us=%lld "
            "finish_us=%lld display_prepare_us=%lld display_transfer_us=%lld pushes=%lu "
            "stroke_us=%lu touch_average_us=%llu touch_max_us=%lu "
            "max_input_lag_us=%lu max_queue=%lu\n",
            static_cast<unsigned long>(stroke_samples), static_cast<long long>(stroke_render_us),
            static_cast<long long>(stroke_samples == 0 ? 0 : stroke_render_us / stroke_samples),
            static_cast<long long>(maximum_render_us), static_cast<long long>(finish_us),
            static_cast<long long>(timing.prepare_us), static_cast<long long>(timing.transfer_us),
            static_cast<unsigned long>(timing.pushes),
            static_cast<unsigned long>(event.timestamp_us - stroke_started_us),
            static_cast<unsigned long long>(
                stroke_samples <= 1 ? 0 : touch_intervals_us / (stroke_samples - 1U)),
            static_cast<unsigned long>(maximum_touch_interval_us),
            static_cast<unsigned long>(maximum_input_lag_us),
            static_cast<unsigned long>(maximum_queue_depth));
        update_toolbar();
      }
    }
  }
}
