#ifndef TINYDRAW_VECTOR_V2_TILE_PRODUCER_H
#define TINYDRAW_VECTOR_V2_TILE_PRODUCER_H

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>

#include "tinydraw/vector_v2/incremental_rasterizer.h"
#include "tinydraw/vector_v2/operation_log.h"
#include "tinydraw/vector_v2/render_accounting.h"
#include "tinydraw/vector_v2/replay_block_index.h"

namespace tinydraw::vector_v2 {

inline constexpr int kTileProducerColumns = 2;
inline constexpr int kTileProducerRows = 2;
inline constexpr int kTileProducerWidth = kTileProducerColumns * kTileWidth;
inline constexpr int kTileProducerHeight = kTileProducerRows * kTileHeight;
inline constexpr std::size_t kTileProducerPixels =
    static_cast<std::size_t>(kTileProducerWidth) * kTileProducerHeight;
inline constexpr std::size_t kTileProducerMaskBytes = (kTileProducerPixels + 7U) / 8U;
inline constexpr std::size_t kTileProducerSummaryRows =
    static_cast<std::size_t>(kTileProducerHeight);
inline constexpr std::size_t kTileProducerSummaryWords = (kTileProducerSummaryRows + 31U) / 32U;
inline constexpr std::size_t kTileProducerOperationBatch = 64;
inline constexpr std::size_t kTileProducerSampleBatch = 96;
// Conservative projected bounding-box work budget. It complements the sample
// cap because raster cost also grows with segment length and radius.
inline constexpr std::size_t kTileProducerRasterWorkBatch = 16'000;

struct TileProducerWorkspace {
  // Row-major 128x128 supertask surface.
  std::span<std::uint16_t> supertask_pixels{};
  // Tightly packed publication scratch for one 64x64-or-smaller edge tile.
  std::span<std::uint16_t> packed_tile_pixels{};
  // One finalized bit per supertask pixel for exact newest-first replay.
  std::span<std::uint8_t> finalized_pixels{};
  // Exact row-saturation summary over the supertask mask: per-row unfinalized
  // counts plus a saturated-row bitmap. Lets replay skip saturated rows,
  // segments, operations, and complete groups in O(1) with bit-identical
  // output.
  std::span<std::uint16_t> summary_row_unset{};
  std::span<std::uint32_t> summary_saturated_words{};
  // Optional host-prototype storage. Empty preserves the exact linear replay
  // fallback; a full kReplayIndexWords span enables indexed discovery.
  std::span<std::uint32_t> replay_index_words{};
};

struct CandidateDiscoveryCounters {
  std::size_t operations_scanned = 0;
  std::size_t operations_intersecting = 0;
  std::size_t groups_published = 0;
};

struct TileProductionStep {
  PixelRect level_bounds{};
  std::size_t operations_scanned = 0;
  std::size_t operations_intersecting = 0;
  std::size_t operations_rendered = 0;
  std::size_t groups_published = 0;
  std::size_t raster_steps = 0;
  std::size_t raster_work = 0;
  std::size_t tiles_published = 0;
  // Valid only after publication (`tiles_published != 0`) or on a complete
  // result. Resumable replay-only slices leave this at zero.
  std::size_t visible_tiles_remaining = 0;
  bool complete = false;
};

// Cold-produces provisional world-aligned tiles from a uniform baseline and a
// exact newest-first replay range. A finalized-pixel mask makes first writer
// win, which is equivalent to forward painter order for opaque pen/eraser ops.
// This is the Gate 1 raw-source producer, not a
// settled renderer: output is always kImmediate. All storage is caller-owned.
// Callers serialize the log, canvas, producer, and workspace.
class TileProducer {
 public:
  TileProducer(OperationLog& log, MaterializedCanvas& canvas, TileProducerWorkspace workspace,
               DocumentRevision uniform_baseline_revision = {},
               std::uint16_t baseline_color = 0xFFFFU,
               RenderAccounting* render_accounting = nullptr);

  [[nodiscard]] bool ready() const;
  // Produces the closest missing 2x2 supertask for a tiled viewport. A complete
  // result means every visible key has a current tile at kImmediate or better.
  [[nodiscard]] std::optional<TileProductionStep> produce_next(const ViewRequest& view);
  [[nodiscard]] std::optional<std::size_t> visible_tiles_remaining(const ViewRequest& view) const;
  [[nodiscard]] const CandidateDiscoveryCounters& candidate_counters() const;
  void reset_candidate_counters();
  // Lets append owners keep cold-start timing free of index maintenance. Empty
  // optional index storage is a successful no-op for existing device callers.
  [[nodiscard]] bool sync_replay_index();
  // Changes the authoritative uniform snapshot after a coordinated log/canvas
  // reset. Rejected unless both authorities are empty and at this revision.
  [[nodiscard]] bool reset_uniform_baseline(DocumentRevision revision,
                                            std::uint16_t color = 0xFFFFU);

 private:
  struct GroupPublication {
    PixelRect level_bounds{};
    std::size_t tiles_published = 0;
  };

  enum class OperationGate : std::uint8_t {
    kFailed,
    kConsumed,
    kReady,
  };

  struct ActiveGroup {
    ViewRequest view{};
    TileKey origin{};
    PixelRect bounds{};
    OperationLogEpoch epoch{};
    DocumentRevision revision{};
    ReplayCandidateCursor candidates{};
    // Current reverse segment endpoint. Zero initializes a newly selected
    // operation; single-sample operations are handled as one bounded unit.
    std::size_t next_sample = 0;
    // One curved endpoint emits two bounded centerline segments plus a final
    // tail when needed. Zero initializes the endpoint; replay consumes the
    // segments in reverse index order so every producer tick stays bounded.
    std::size_t next_curve_step = 0;
    // Operation-level visibility and saturation gates run once per operation;
    // the passing fetch is cached here so per-segment replay touches neither
    // the log nor the operation-level rectangle math again. The cached spans
    // stay valid because render_active_batch revalidates epoch and revision
    // before every batch.
    std::size_t cached_operation_index = kNoCachedOperation;
    StoredOperation cached_operation{};
    bool active = false;
  };

  static constexpr std::size_t kNoCachedOperation = static_cast<std::size_t>(-1);

  [[nodiscard]] static bool valid_view(const ViewRequest& view);
  [[nodiscard]] bool tile_satisfies(TileKey key, MaterializationQuality quality) const;
  [[nodiscard]] std::optional<TileKey> choose_certain_paper_group(const ViewRequest& view) const;
  [[nodiscard]] std::optional<TileProductionStep> publish_certain_paper_group(
      const ViewRequest& view, TileKey origin);
  [[nodiscard]] std::optional<std::size_t> visible_tiles_remaining(
      const ViewRequest& view, MaterializationQuality quality) const;
  [[nodiscard]] std::optional<TileKey> choose_missing_group(const ViewRequest& view) const;
  [[nodiscard]] bool start_group(const ViewRequest& view, TileKey group_origin);
  [[nodiscard]] bool active_group_has_work() const;
  [[nodiscard]] RenderGroupKey active_group_key() const;
  void discard_active_group();
  void record_view_reuses(const ViewRequest& view);
  void consume_active_operation(TileProductionStep& result, std::size_t& operations_consumed);
  [[nodiscard]] OperationGate gate_active_operation(TileProductionStep& result,
                                                    std::size_t& operations_consumed);
  void finish_active_segment(std::size_t endpoint, TileProductionStep& result,
                             std::size_t& operations_consumed);
  [[nodiscard]] bool render_active_segment(TileProductionStep& result,
                                           std::size_t& operations_consumed,
                                           std::size_t& raster_steps_consumed,
                                           std::size_t& raster_work_consumed);
  [[nodiscard]] std::optional<TileProductionStep> render_active_batch();
  [[nodiscard]] std::optional<GroupPublication> publish_group(PixelRect rendered_bounds,
                                                              PixelRect visible_bounds,
                                                              ZoomLevel zoom,
                                                              DocumentRevision revision);
  [[nodiscard]] bool publish_surface_tile(TileKey key, PixelRect rendered_bounds,
                                          DocumentRevision revision);
  static void include_bounds(PixelRect bounds, GroupPublication& publication);
  OperationLog& log_;
  MaterializedCanvas& canvas_;
  TileProducerWorkspace workspace_;
  MaskedRowSummary summary_;
  ReplayBlockIndex replay_index_;
  RenderAccounting* render_accounting_ = nullptr;
  CandidateDiscoveryCounters candidate_counters_{};
  DocumentRevision baseline_revision_{};
  std::uint16_t baseline_color_ = 0xFFFFU;
  ActiveGroup active_group_{};
};

}  // namespace tinydraw::vector_v2

#endif  // TINYDRAW_VECTOR_V2_TILE_PRODUCER_H
