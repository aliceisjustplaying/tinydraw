#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

#include "tinydraw/ink/ink_stream.h"

namespace tinydraw {

enum class RibbonPrimitiveKind { kConvex, kCircle };

struct RibbonPrimitive {
  RibbonPrimitiveKind kind = RibbonPrimitiveKind::kConvex;
  std::array<Point, 4> points{};
  std::uint8_t point_count = 0;
  Point center{};
  float radius = 0.0F;
};

class RibbonPrimitiveBatch {
 public:
  [[nodiscard]] const RibbonPrimitive* begin() const { return primitives_.data(); }
  [[nodiscard]] const RibbonPrimitive* end() const { return begin() + count_; }
  [[nodiscard]] std::size_t size() const { return count_; }
  [[nodiscard]] bool empty() const { return count_ == 0U; }

 private:
  friend class RibbonStream;
  friend class CurvedRibbonStream;
  void push_back(RibbonPrimitive primitive);

  // Enough for a split two-span curve, initial cap, split provisional tail, and final cap.
  std::array<RibbonPrimitive, 8> primitives_{};
  std::size_t count_ = 0;
};

struct RibbonUpdate {
  RibbonPrimitiveBatch committed;
  RibbonPrimitiveBatch provisional;
};

// Emits geometry that has become append-stable plus a replacement tail for display.
// InkPoint radii are immutable inputs, so initial pressure never revises older geometry.
class RibbonStream {
 public:
  [[nodiscard]] RibbonUpdate append(InkPoint point);
  [[nodiscard]] RibbonUpdate finish(InkPoint point);
  void reset();

  [[nodiscard]] bool active() const { return point_count_ != 0U; }

 private:
  InkPoint first_{};
  InkPoint prior_{};
  InkPoint last_{};
  Point tail_left_{};
  Point tail_right_{};
  std::size_t point_count_ = 0;
  bool first_cap_pending_ = false;
};

// Reconstructs a smooth midpoint-quadratic path from sparse controller reports.
// Stable curves lag by one input point; a replaceable straight tail still reaches the finger.
class CurvedRibbonStream {
 public:
  // provisional_needed=false skips building the replaceable display tail for
  // offline replay; committed geometry is identical either way.
  [[nodiscard]] RibbonUpdate append(InkPoint point, bool provisional_needed = true);
  [[nodiscard]] RibbonUpdate finish(InkPoint point);
  void reset();

  [[nodiscard]] bool active() const { return point_count_ != 0U; }

 private:
  InkPoint first_{};
  InkPoint stable_{};
  InkPoint last_{};
  std::size_t point_count_ = 0;
  bool first_cap_pending_ = false;
};

// Build simple unionable pieces rather than one self-intersecting outline.
// The stream has already supplied dt-adapted positions, pressure, and radii.
[[nodiscard]] std::vector<RibbonPrimitive> build_pf_ribbon(std::span<const InkPoint> points);

}  // namespace tinydraw
