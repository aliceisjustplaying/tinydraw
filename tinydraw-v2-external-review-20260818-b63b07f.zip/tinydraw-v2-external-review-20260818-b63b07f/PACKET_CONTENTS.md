# Packet contents

This archive contains commit `b63b07f905b40b3d435679911d2de89e57e1f062`
from branch `cleanup/v2-degoldplate`. The filtered working-tree status is empty.

`source/` preserves repository-relative paths for the current contract, design
documents, compact receipts, core and Vector V2 code, retained Raster V1 and
host code, ESP32 integration, tests, fixtures, vendored build dependencies, and
the scripts used by the documented validation commands.

`provenance/` contains the exact commit and branch, recent history, the cleanup
diff summary against `v2-feature-complete-pre-cleanup`, and complete output from
the three quality tools that still report findings. `VALIDATION.md` records the
passing host, firmware, QEMU, and physical-device evidence.

The archive omits generated builds, raw serial/video evidence, credentials,
managed ESP-IDF components, local reference clones, unrelated datasheets,
prior review archives, and concluded AI transcripts. The Wi-Fi credentials
example is present; the local credentials header is absent.

`MANIFEST.sha256` covers every other file in the archive. Verify it from the
packet root with:

```sh
shasum -a 256 -c MANIFEST.sha256
```
