#ifndef TINYDRAW_VECTOR_V2_SVG_EXPORT_H
#define TINYDRAW_VECTOR_V2_SVG_EXPORT_H

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string_view>

#include "tinydraw/vector_v2/operation_log.h"

namespace tinydraw::vector_v2 {

class SvgByteSink {
 public:
  virtual ~SvgByteSink() = default;

  // Appends one short fragment. Implementations may write it directly to
  // caller-owned storage, flash, or a file and must not retain the view.
  [[nodiscard]] virtual bool append(std::string_view bytes) = 0;
};

using SvgExportProgress = void (*)(std::size_t completed_operations, std::size_t total_operations,
                                   void* context);

struct SvgExportOptions {
  PixelRect world_bounds{0, 0, kWorldWidth, kWorldHeight};
  std::uint16_t background = 0xFFFFU;
  SvgExportProgress progress = nullptr;
  void* progress_context = nullptr;
};

// Streams a standalone SVG from the painter-ordered operation authority.
// Adjacent operation chunks with one nonzero gesture ID become one filled SVG
// path: a physical finger-down/up stroke is the logical export unit even when
// bounded live-input storage split it internally. Ungrouped legacy operations
// remain individual paths. Each path contains consistently wound subpaths for
// the exact circles and convex shapes emitted by CurvedRibbonStream, the same
// variable-width ribbon geometry used by the renderer. Nonzero filling makes
// their union identical to the rendered stroke without a centerline or
// stroke-width approximation. The root has no synthetic background rectangle;
// erasers use the requested opaque background color and retain painter order.
//
// No document-sized output or geometry buffer is allocated. Formatting and
// sink batching use fixed stack storage plus RibbonPrimitiveBatch's bounded
// inline storage.
// Callers must serialize mutation of log for the duration of this authority
// snapshot read. A sink failure or authority change makes the export fail.
[[nodiscard]] bool export_svg(const OperationLog& log, SvgByteSink& sink,
                              SvgExportOptions options = {});

// Counts the logical paths export_svg will emit without encoding geometry.
// Callers must serialize mutation of log for this snapshot read.
[[nodiscard]] std::optional<std::size_t> svg_path_count(const OperationLog& log);

}  // namespace tinydraw::vector_v2

#endif  // TINYDRAW_VECTOR_V2_SVG_EXPORT_H
