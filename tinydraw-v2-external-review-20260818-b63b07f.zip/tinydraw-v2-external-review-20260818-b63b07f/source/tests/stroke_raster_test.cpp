#include "tinydraw/graphics/stroke_raster.h"

#include <doctest.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

#include "tinydraw/graphics/ribbon_renderer.h"
#include "tinydraw/graphics/tile_undo_history.h"
#include "tinydraw/ink/ink_stream.h"

namespace {

constexpr std::uint16_t kBackground = 0xFFFFU;
constexpr std::uint16_t kInk = 0x001FU;
constexpr std::size_t kPixelCount =
    static_cast<std::size_t>(tinydraw::kCanvasWidth * tinydraw::kCanvasHeight);

struct RasterFixture {
  std::vector<std::uint16_t> committed = std::vector<std::uint16_t>(kPixelCount, kBackground);
  std::vector<std::uint16_t> visible = committed;
  std::vector<std::uint8_t> coverage = std::vector<std::uint8_t>(kPixelCount, 0U);
  tinydraw::StrokeRaster raster{committed, visible, coverage};
};

struct RecordingDisplay final : tinydraw::DisplayBackend {
  std::vector<std::uint16_t> pixels = std::vector<std::uint16_t>(kPixelCount, kBackground);
  std::uint32_t pushes = 0U;

  void push_rect(int x, int y, int width, int height, const std::uint16_t* rgb565,
                 int stride = 0) override {
    const int source_stride = stride == 0 ? width : stride;
    ++pushes;
    for (int row = 0; row < height; ++row) {
      std::copy_n(rgb565 + row * source_stride, width,
                  pixels.begin() + (y + row) * tinydraw::kCanvasWidth + x);
    }
  }
};

tinydraw::InkPoint ink_point(float x, float y, float radius) {
  return {
      .position = {x, y},
      .pressure = 0.0F,
      .radius = radius,
      .distance = 0.0F,
      .running_length = 0.0F,
      .timestamp_us = 0U,
  };
}

std::size_t changed_pixels(const std::vector<std::uint16_t>& pixels) {
  return static_cast<std::size_t>(std::count_if(
      pixels.begin(), pixels.end(), [](std::uint16_t pixel) { return pixel != kBackground; }));
}

void append_geometry(std::vector<tinydraw::RibbonPrimitive>& geometry, std::size_t& committed_count,
                     const tinydraw::RibbonUpdate& update) {
  geometry.resize(committed_count);
  geometry.insert(geometry.end(), update.committed.begin(), update.committed.end());
  committed_count = geometry.size();
  geometry.insert(geometry.end(), update.provisional.begin(), update.provisional.end());
}

}  // namespace

TEST_CASE("provisional stroke pixels never enter the persistent canvas") {
  RasterFixture fixture;
  tinydraw::RibbonStream ribbon;
  const tinydraw::InkPoint first = ink_point(40.0F, 80.0F, 8.0F);
  const tinydraw::InkPoint second = ink_point(80.0F, 90.0F, 8.0F);

  const auto first_stats = fixture.raster.update(ribbon.append(first), kInk);
  const auto second_stats = fixture.raster.update(ribbon.append(second), kInk);

  CHECK(first_stats.display_bytes == first_stats.committed_bytes_read);
  CHECK(second_stats.display_bytes == second_stats.committed_bytes_read);
  CHECK(first_stats.committed_bytes_written == 0U);
  CHECK(second_stats.committed_bytes_written == 0U);
  CHECK(first_stats.coverage_bytes_read > 0U);
  CHECK(changed_pixels(fixture.visible) > 0U);
  CHECK(changed_pixels(fixture.committed) == 0U);

  const auto finish_stats = fixture.raster.finish(ribbon.finish(second), kInk);

  CHECK(finish_stats.display_bytes == finish_stats.committed_bytes_read);
  CHECK(finish_stats.committed_bytes_written == finish_stats.display_bytes);
  CHECK(finish_stats.coverage_bytes_written >= finish_stats.committed_bytes_written / 2U);
  CHECK(fixture.visible == fixture.committed);
  CHECK(changed_pixels(fixture.committed) > 0U);
  CHECK(std::all_of(fixture.coverage.begin(), fixture.coverage.end(),
                    [](std::uint8_t value) { return value == 0U; }));
}

TEST_CASE("stroke finish captures dirty tiles from the committed read") {
  RasterFixture fixture;
  const auto initial = fixture.committed;
  std::vector<std::uint16_t> undo_storage(tinydraw::TileUndoHistory::kRequiredPixels);
  tinydraw::TileUndoHistory history(undo_storage);
  tinydraw::RibbonStream ribbon;
  const tinydraw::InkPoint first = ink_point(40.0F, 80.0F, 8.0F);
  const tinydraw::InkPoint second = ink_point(80.0F, 90.0F, 8.0F);

  static_cast<void>(fixture.raster.update(ribbon.append(first), kInk));
  const auto stats = fixture.raster.finish(ribbon.finish(second), kInk, &history);

  CHECK(history.entry_count() == 1U);
  CHECK(stats.history_bytes_written == stats.committed_bytes_read);
  CHECK(changed_pixels(fixture.committed) > 0U);
  CHECK(history.undo(fixture.committed, fixture.visible).tiles_restored > 0U);
  CHECK(fixture.committed == initial);
  CHECK(fixture.visible == initial);
}

TEST_CASE("stroke raster presents one complete dirty region when a visible canvas is available") {
  std::vector<std::uint16_t> committed(kPixelCount, kBackground);
  std::vector<std::uint16_t> visible = committed;
  std::vector<std::uint8_t> coverage(kPixelCount, 0U);
  RecordingDisplay display;
  tinydraw::StrokeRaster raster{committed, visible, coverage, display};
  tinydraw::RibbonStream ribbon;
  const tinydraw::InkPoint first = ink_point(40.0F, 80.0F, 8.0F);
  const tinydraw::InkPoint second = ink_point(80.0F, 90.0F, 8.0F);

  static_cast<void>(raster.update(ribbon.append(first), kInk));
  CHECK(display.pushes == 1U);
  CHECK(display.pixels == visible);

  static_cast<void>(raster.update(ribbon.append(second), kInk));
  CHECK(display.pushes == 2U);
  CHECK(display.pixels == visible);
}

TEST_CASE("incremental stroke raster can submit dirty tiles without a visible canvas") {
  std::vector<std::uint16_t> committed(kPixelCount, kBackground);
  std::vector<std::uint8_t> coverage(kPixelCount, 0U);
  RecordingDisplay display;
  tinydraw::StrokeRaster raster{committed, coverage, display};
  tinydraw::RibbonStream ribbon;
  const tinydraw::InkPoint first = ink_point(40.0F, 80.0F, 8.0F);
  const tinydraw::InkPoint second = ink_point(80.0F, 90.0F, 8.0F);

  static_cast<void>(raster.update(ribbon.append(first), kInk));
  static_cast<void>(raster.update(ribbon.append(second), kInk));

  CHECK(display.pushes > 0U);
  CHECK(changed_pixels(display.pixels) > 0U);
  CHECK(changed_pixels(committed) == 0U);

  static_cast<void>(raster.finish(ribbon.finish(second), kInk));

  CHECK(display.pixels == committed);
}

TEST_CASE("firmware-style cancel restores provisional display tiles") {
  std::vector<std::uint16_t> committed(kPixelCount, kBackground);
  std::vector<std::uint8_t> coverage(kPixelCount, 0U);
  RecordingDisplay display;
  tinydraw::StrokeRaster raster{committed, coverage, display};
  tinydraw::RibbonStream ribbon;
  const tinydraw::InkPoint first = ink_point(40.0F, 80.0F, 8.0F);
  const tinydraw::InkPoint second = ink_point(80.0F, 90.0F, 8.0F);

  static_cast<void>(raster.update(ribbon.append(first), kInk));
  static_cast<void>(raster.update(ribbon.append(second), kInk));
  CHECK(changed_pixels(display.pixels) > 0U);

  raster.cancel();

  CHECK(display.pixels == committed);
  CHECK(changed_pixels(committed) == 0U);
  CHECK(std::all_of(coverage.begin(), coverage.end(), [](auto value) { return value == 0U; }));
}

TEST_CASE("incremental stroke raster matches one-pass coverage union") {
  RasterFixture fixture;
  tinydraw::RibbonStream ribbon;
  std::vector<tinydraw::RibbonPrimitive> geometry;
  std::size_t committed_count = 0U;

  for (int index = 0; index < 80; ++index) {
    const float step = static_cast<float>(index);
    const tinydraw::InkPoint point =
        ink_point(30.0F + step * 3.0F, 150.0F + 50.0F * std::sin(step * 0.18F), 7.0F);
    const auto update = index + 1 == 80 ? ribbon.finish(point) : ribbon.append(point);
    append_geometry(geometry, committed_count, update);
    if (index + 1 == 80) {
      static_cast<void>(fixture.raster.finish(update, kInk));
    } else {
      static_cast<void>(fixture.raster.update(update, kInk));
    }
  }

  std::vector<std::uint16_t> expected(kPixelCount, kBackground);
  tinydraw::RibbonRenderer renderer;
  static_cast<void>(
      renderer.render(geometry, expected, tinydraw::kCanvasWidth, tinydraw::kCanvasHeight, kInk));

  CHECK(fixture.committed == expected);
}

TEST_CASE("XL stroke update work stays bounded as the gesture grows") {
  RasterFixture fixture;
  tinydraw::InkConfig config;
  config.size = 20.0F;
  tinydraw::InkStream ink(config);
  tinydraw::RibbonStream ribbon;
  std::uint32_t maximum_tile_visits = 0U;
  std::uint32_t maximum_tiles = 0U;
  bool display_counts_match = true;

  for (int index = 0; index < 500; ++index) {
    const float step = static_cast<float>(index);
    const tinydraw::TouchPoint touch{
        .x = 30.0F + std::fmod(step * 2.3F, 300.0F),
        .y = 200.0F + 120.0F * std::sin(step * 0.09F),
        .timestamp_us = static_cast<std::uint32_t>(index * 8'000),
    };
    const auto point = index == 0 ? ink.begin(touch) : ink.update(touch);
    const auto stats = fixture.raster.update(ribbon.append(point), kInk);
    maximum_tile_visits = std::max(maximum_tile_visits, stats.primitive_tile_visits);
    maximum_tiles = std::max(maximum_tiles, stats.tiles_updated);
    display_counts_match =
        display_counts_match && stats.display_bytes == stats.pixels_composited * 2U &&
        stats.display_bytes == stats.committed_bytes_read && stats.committed_bytes_written == 0U;
  }

  CHECK(maximum_tile_visits <= 100U);
  CHECK(maximum_tiles <= 20U);
  CHECK(display_counts_match);
}
