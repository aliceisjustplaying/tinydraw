#pragma once

#include <array>
#include <cstdint>
#include <span>

#include "tinydraw/geometry.h"

namespace tinydraw {

inline constexpr int kTileSize = 64;
inline constexpr int kStrokeTileSize = 32;

class CoverageTile {
 public:
  CoverageTile(int origin_x, int origin_y, int width = kTileSize, int height = kTileSize);

  void reset(int origin_x, int origin_y, int width = kTileSize, int height = kTileSize);
  void clear();
  void union_coverage(int x, int y, std::uint8_t coverage);
  [[nodiscard]] std::uint8_t coverage_at(int x, int y) const;

  void rasterize_circle(Point center, float radius);
  void rasterize_convex(std::span<const Point> polygon);

  [[nodiscard]] int origin_x() const { return origin_x_; }
  [[nodiscard]] int origin_y() const { return origin_y_; }
  [[nodiscard]] int width() const { return width_; }
  [[nodiscard]] int height() const { return height_; }
  [[nodiscard]] std::uint8_t* row(int y);
  [[nodiscard]] const std::uint8_t* row(int y) const;
  [[nodiscard]] const std::uint8_t* data() const { return coverage_.data(); }

  // Local-coordinate bounds of possibly-nonzero coverage; empty when
  // left > right. Lets clearing and compositing skip untouched pixels.
  // Callers that write through row() must call mark_dirty for that region.
  void mark_dirty(int left, int top, int right, int bottom);
  [[nodiscard]] int dirty_left() const { return dirty_left_; }
  [[nodiscard]] int dirty_top() const { return dirty_top_; }
  [[nodiscard]] int dirty_right() const { return dirty_right_; }
  [[nodiscard]] int dirty_bottom() const { return dirty_bottom_; }

 private:
  [[nodiscard]] bool contains(int x, int y) const;
  [[nodiscard]] std::size_t index_of(int x, int y) const;

  int origin_x_;
  int origin_y_;
  int width_;
  int height_;
  int dirty_left_ = 0;
  int dirty_top_ = 0;
  int dirty_right_ = -1;
  int dirty_bottom_ = -1;
  std::array<std::uint8_t, kTileSize * kTileSize> coverage_{};
};

// Blend directly in stored sRGB-like RGB565 channel space. The destination is
// a contiguous tile with coverage.width() × coverage.height() pixels.
void composite_rgb565(const CoverageTile& coverage, std::uint16_t source,
                      std::span<std::uint16_t> destination);

}  // namespace tinydraw
